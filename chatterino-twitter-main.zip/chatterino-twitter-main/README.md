# chatterino-twitter

For this to work, you need to have Chatterino logging enabled. You can find this setting under the moderation tab. 

After you have it enabled, run requirements.bat

Then, edit main.py

Choose the file path to "Chatterino2\\Logs\\Twitch\\Mentions\\" IMPORTANT: If you copy paste from file explorer, be sure to add extra backslashes between the paths. 

Next, use https://tweeterid.com to find your user_id. Input the id in the quotes next to user_id.

After saving main.py, run start.bat. Now, everytime you recieve a mention on chatterino, you will recieve a twitter dm. 

IMPORTANT: If you don't recieve a mention, check if your privacy settings are preventing someone you are not following from dming you, or follow @f0rg3t__tv on twitter.
